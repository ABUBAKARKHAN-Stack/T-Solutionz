
# Corporate Multi-Page Website with Nature-Inspired Theme

## Theme & Colors
- **Primary/Light**: `#acc8a2` (soft sage green) — used for backgrounds, cards, hover states
- **Accent/Dark**: `#1a2517` (deep forest green) — used for text, buttons, navbar, footer
- **Derived variants**: Primary-foreground, secondary, muted, border colors will all be refined from these two base colors to create a cohesive corporate-yet-natural palette
- Professional, clean aesthetic with structured layouts

## Navigation
- **Top navbar** with logo on the left, page links (Home, About, Services, Contact) on the right
- **Mobile hamburger menu** that slides open with the same links
- Sticky/fixed navbar with subtle background on scroll

## Pages

### 1. Home / Landing Page
- **Hero Section**: Large headline with subtext and a CTA button, possibly with a background image or gradient using the theme colors
- **Features Section**: Grid of feature cards with icons, short titles, and descriptions
- **Partners/Logos Section**: Row of partner or client logos as trust indicators
- **Testimonials Section**: Customer quotes in a card or carousel layout

### 2. About Page
- Company mission/vision section with text and imagery
- Team section or company story
- Values or milestones

### 3. Services Page
- Grid or list of services with icons/illustrations
- Short descriptions for each service
- CTA to contact or learn more

### 4. Contact Page
- Contact form (name, email, subject, message)
- Company address and contact details
- Optional map placeholder

## Footer (All Pages)
- Multi-column layout with quick links, contact info, social media icons
- Copyright text at the bottom
- Styled with the dark accent color (`#1a2517`)

## Technical Notes
- No backend needed — fully static/frontend-only
- Responsive design for desktop, tablet, and mobile
- Smooth scroll and page transitions
