import { Code2, Smartphone, Cloud, Container, Brain, TrendingUp, Shield, Users, Zap, Lightbulb, Globe, Target, Eye, Heart, Award, Clock, HeartHandshake, Sparkles, Search, BarChart3, Cpu, Leaf, Rocket } from "lucide-react";

import serviceFullstack from "@/assets/service-fullstack.jpg";
import serviceAppdev from "@/assets/service-appdev.jpg";
import serviceCloud from "@/assets/service-cloud.jpg";
import serviceDevops from "@/assets/service-devops.jpg";
import serviceAi from "@/assets/service-ai.jpg";
import caseEcosphere from "@/assets/case-ecosphere.jpg";
import caseTechvault from "@/assets/case-techvault.jpg";
import caseNovabridge from "@/assets/case-novabridge.jpg";
import caseEcosphereBefore from "@/assets/case-ecosphere-before.jpg";
import caseTechvaultBefore from "@/assets/case-techvault-before.jpg";
import caseNovabridgeBefore from "@/assets/case-novabridge-before.jpg";

// ── Navigation ──────────────────────────────────────────────
export const navLinks = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Services", to: "/services", hasDropdown: true },
  { label: "Portfolio", to: "/portfolio" },
  { label: "Contact", to: "/contact" },
];

export const footerLinks = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Services", to: "/services" },
  { label: "Portfolio", to: "/portfolio" },
  { label: "Contact", to: "/contact" },
];

// ── Services ────────────────────────────────────────────────
export const serviceItems = [
  { icon: Code2, label: "Full Stack Development", description: "End-to-end web applications" },
  { icon: Smartphone, label: "App Development", description: "iOS, Android & cross-platform" },
  { icon: Cloud, label: "Cloud Solutions", description: "Scalable cloud infrastructure" },
  { icon: Container, label: "DevOps & Automation", description: "CI/CD & infrastructure as code" },
  { icon: Brain, label: "AI & Machine Learning", description: "Intelligent automation & insights" },
];

export const services = [
  { icon: Code2, title: "Full Stack Development", slug: "full-stack-development", description: "Build robust, scalable web applications from frontend to backend with modern technology stacks.", longDescription: "We deliver end-to-end web applications using cutting-edge technologies like React, Node.js, TypeScript, and PostgreSQL. From responsive UI design to robust API architecture and database optimization, our full stack team handles every layer of your application. We follow best practices in code quality, testing, and security to ensure your product is production-ready and maintainable.", num: "01", image: serviceFullstack, tags: ["React", "Node.js", "TypeScript", "APIs"], deliverables: ["Full application architecture design", "Frontend & backend development", "API design & integration", "Testing & deployment pipeline"] },
  { icon: Smartphone, title: "App Development", slug: "app-development", description: "Create stunning mobile experiences for iOS, Android, and cross-platform with native performance.", longDescription: "We build high-performance mobile applications that users love. Whether you need a native iOS/Android app or a cross-platform solution with React Native or Flutter, our team delivers pixel-perfect UI, smooth animations, and seamless backend integration. We handle everything from prototyping and design to App Store deployment and post-launch support.", num: "02", image: serviceAppdev, tags: ["React Native", "Flutter", "iOS", "Android"], deliverables: ["UI/UX design & prototyping", "Cross-platform or native development", "Backend API integration", "App Store submission & launch support"] },
  { icon: Cloud, title: "Cloud Solutions", slug: "cloud-solutions", description: "Design and deploy scalable cloud infrastructure that grows with your business.", longDescription: "We architect cloud solutions on AWS, Azure, and GCP that are secure, cost-efficient, and infinitely scalable. From initial migration strategies to serverless architectures and microservices, we help you leverage the full power of the cloud. Our team ensures high availability, disaster recovery, and optimized performance across all your workloads.", num: "03", image: serviceCloud, tags: ["AWS", "Azure", "GCP", "Serverless"], deliverables: ["Cloud architecture design", "Migration strategy & execution", "Cost optimization audit", "Security & compliance setup"] },
  { icon: Container, title: "DevOps & Automation", slug: "devops-automation", description: "Streamline your development workflow with CI/CD pipelines, containerization, and infrastructure as code.", longDescription: "We implement DevOps practices that accelerate your development lifecycle and improve reliability. From setting up CI/CD pipelines with GitHub Actions or Jenkins to containerizing applications with Docker and Kubernetes, we automate everything from testing to deployment. Our infrastructure-as-code approach using Terraform and Ansible ensures reproducible, version-controlled environments.", num: "04", image: serviceDevops, tags: ["Docker", "Kubernetes", "CI/CD", "Terraform"], deliverables: ["CI/CD pipeline setup", "Container orchestration", "Infrastructure as code", "Monitoring & alerting setup"] },
  { icon: Brain, title: "AI & Machine Learning", slug: "ai-machine-learning", description: "Integrate intelligent automation, predictive analytics, and AI-powered features into your products.", longDescription: "We bring the power of AI and machine learning to your business. From building custom ML models and NLP pipelines to integrating GPT-powered features and computer vision, we help you unlock insights from your data and automate complex workflows. Our solutions are production-grade, scalable, and designed to deliver measurable business impact.", num: "05", image: serviceAi, tags: ["LLMs", "Computer Vision", "NLP", "Predictive Analytics"], deliverables: ["AI feasibility assessment", "Custom model development", "API integration & deployment", "Performance monitoring & retraining"] },
];

export const homeServices = [
  { icon: Code2, title: "Full Stack Development", slug: "full-stack-development", description: "Build robust, scalable web applications from frontend to backend.", num: "01", image: serviceFullstack, tags: ["React", "Node.js", "TypeScript"] },
  { icon: Smartphone, title: "App Development", slug: "app-development", description: "Stunning mobile experiences for iOS, Android & cross-platform.", num: "02", image: serviceAppdev, tags: ["React Native", "Flutter"] },
  { icon: Cloud, title: "Cloud Solutions", slug: "cloud-solutions", description: "Scalable cloud infrastructure that grows with your business.", num: "03", image: serviceCloud, tags: ["AWS", "Azure", "GCP"] },
  { icon: Container, title: "DevOps & Automation", slug: "devops-automation", description: "CI/CD pipelines, containerization, and infrastructure as code.", num: "04", image: serviceDevops, tags: ["Docker", "Kubernetes"] },
  { icon: Brain, title: "AI & Machine Learning", slug: "ai-machine-learning", description: "Intelligent automation, predictive analytics & AI-powered features.", num: "05", image: serviceAi, tags: ["LLMs", "ML Models"] },
];

export const footerServices = ["Full Stack Development", "App Development", "Cloud Solutions", "DevOps & Automation", "AI & Machine Learning"];

// ── Features (Home) ─────────────────────────────────────────
export const features = [
  { icon: Code2, title: "Full Stack Apps", description: "End-to-end web applications built with modern frameworks and scalable architecture.", num: "01" },
  { icon: Smartphone, title: "Mobile First", description: "Cross-platform mobile apps with native performance and beautiful user experiences.", num: "02" },
  { icon: Cloud, title: "Cloud Native", description: "Scalable cloud infrastructure on AWS, Azure, and GCP designed for growth.", num: "03" },
  { icon: Container, title: "DevOps Pipeline", description: "Automated CI/CD, containerization, and infrastructure as code for rapid delivery.", num: "04" },
  { icon: Brain, title: "AI Integration", description: "Smart automation, predictive analytics, and LLM-powered features for your products.", num: "05" },
  { icon: Globe, title: "Global Scale", description: "Distributed systems and edge computing to serve users worldwide with low latency.", num: "06" },
];

// ── Partners ────────────────────────────────────────────────
export const partners = ["TechVault", "Horizon Inc", "NovaBridge", "EcoSphere", "PeakPoint"];

// ── Stats (About Preview) ───────────────────────────────────
export const stats = [
  { val: 200, suffix: "+", label: "Clients Served" },
  { val: 95, suffix: "%", label: "Client Retention" },
  { val: 30, suffix: "+", label: "Industries" },
  { val: 10, suffix: "+", label: "Years Experience" },
];

// ── About Page ──────────────────────────────────────────────
export const values = [
  { icon: Target, title: "Purpose-Driven", description: "Every decision we make is guided by our commitment to sustainable growth and positive impact." },
  { icon: Eye, title: "Transparency", description: "We believe in open communication and honest partnerships with every client we serve." },
  { icon: Heart, title: "Integrity", description: "We hold ourselves to the highest ethical standards in everything we do." },
  { icon: Award, title: "Excellence", description: "We strive for exceptional results through innovation, expertise, and dedication." },
];

export const team = [
  { name: "Alexandra Reed", role: "Founder & CEO", initials: "AR" },
  { name: "Marcus Johnson", role: "Head of Strategy", initials: "MJ" },
  { name: "Priya Sharma", role: "Director of Operations", initials: "PS" },
  { name: "David Kim", role: "Lead Consultant", initials: "DK" },
];

// ── Approach ────────────────────────────────────────────────
export const approachSteps = [
  { num: "01", icon: Search, title: "Discover", description: "We analyze your requirements, tech stack, and business goals to define the perfect solution." },
  { num: "02", icon: Lightbulb, title: "Architect", description: "Our engineers design scalable architectures with clear milestones and technology choices." },
  { num: "03", icon: Rocket, title: "Build & Ship", description: "We develop iteratively with CI/CD, keeping you in the loop with demos every sprint." },
  { num: "04", icon: Zap, title: "Scale & Optimize", description: "Continuous monitoring, performance tuning, and feature iteration ensure long-term success." },
];

// ── Why Choose Us ───────────────────────────────────────────
export const whyChooseUsReasons = [
  { icon: Award, title: "Industry Experts", description: "Our team brings decades of combined experience across multiple industries." },
  { icon: Target, title: "Results-Driven", description: "Every engagement is designed around measurable outcomes and KPIs." },
  { icon: HeartHandshake, title: "True Partnership", description: "We work alongside your team, not in isolation — your success is ours." },
  { icon: Clock, title: "Agile Delivery", description: "Fast, iterative execution so you see value from day one." },
  { icon: Shield, title: "Trusted & Transparent", description: "No hidden agendas. Full visibility into progress, costs, and decisions." },
  { icon: Sparkles, title: "Innovation-First", description: "We leverage the latest tools and methodologies to keep you ahead." },
];

// ── Testimonials ────────────────────────────────────────────
export const testimonials = [
  { quote: "T-Solutions brought a fresh perspective to our sustainability roadmap. Their energy and dedication were exactly what our team needed.", name: "Sarah Mitchell", role: "Founder, EcoSphere" },
  { quote: "Working with a young, hungry team made all the difference. They treated our project like their own and delivered beyond expectations.", name: "James Chen", role: "CTO, TechVault" },
  { quote: "Their strategic framework helped us find clarity during a pivotal growth phase. Highly recommend for any startup or scaling business.", name: "Elena Rodriguez", role: "Director, NovaBridge" },
  { quote: "What they lack in decades, they make up for in insight and hustle. T-Solutions is the real deal.", name: "Marcus Liu", role: "Co-founder, PeakPoint" },
  { quote: "They challenged our assumptions in the best way possible. A truly collaborative experience from start to finish.", name: "Aisha Patel", role: "CEO, Horizon Inc" },
];

// ── FAQ ─────────────────────────────────────────────────────
export const faqs = [
  { q: "What industries do you specialize in?", a: "We work across technology, finance, healthcare, energy, and consumer goods. Our frameworks are adaptable to any sector, and we tailor every engagement to your specific market dynamics." },
  { q: "How long does a typical engagement last?", a: "Most projects range from 4 to 16 weeks depending on scope. We start with a discovery phase and provide a clear timeline before any commitment." },
  { q: "Do you work with startups or only enterprises?", a: "Both. We've helped early-stage startups define their go-to-market strategy and guided Fortune 500 companies through digital transformation. Our approach scales to fit your stage." },
  { q: "What makes your sustainability audits different?", a: "We go beyond compliance checklists. Our audits combine environmental impact data with actionable business strategies, ensuring sustainability efforts also drive profitability." },
  { q: "How do you measure success?", a: "Every project begins with defined KPIs. We track progress through regular check-ins, dashboards, and a final impact report so results are always transparent and measurable." },
  { q: "Can we start with a small pilot project?", a: "Absolutely. Many clients start with a focused engagement to experience our approach firsthand before expanding into larger initiatives." },
];

// ── Case Studies (Portfolio) ────────────────────────────────
export const caseStudies = [
  { title: "EcoSphere Sustainability Overhaul", slug: "ecosphere-sustainability", category: "Sustainability", client: "EcoSphere", industry: "Clean Energy", duration: "12 weeks", description: "Reduced carbon emissions by 35% while cutting operational costs through a comprehensive sustainability audit.", longDescription: "EcoSphere, a mid-size clean energy company, approached us to overhaul their sustainability practices across manufacturing and distribution. Our team conducted a full lifecycle carbon analysis, identified 12 key emission reduction opportunities, and implemented a phased green strategy. The result was a 35% reduction in carbon emissions within the first year — alongside a 15% decrease in operational costs through energy optimization and waste reduction.", result: "35% emission reduction", results: ["35% carbon emission reduction", "15% operational cost savings", "$2.1M annual energy savings", "GRI-compliant ESG reporting"], before: caseEcosphereBefore, after: caseEcosphere },
  { title: "TechVault Digital Transformation", slug: "techvault-digital", category: "Digital", client: "TechVault", industry: "Enterprise Software", duration: "16 weeks", description: "Modernized legacy systems and boosted team productivity with AI-powered workflows.", longDescription: "TechVault's engineering team was bottlenecked by legacy infrastructure and manual processes. We mapped their entire technology stack, identified automation opportunities, and designed a cloud migration strategy. Over 16 weeks, we migrated critical systems to a modern cloud architecture, implemented AI-powered code review and testing pipelines, and trained their team on new workflows — resulting in a 2x productivity increase.", result: "2x productivity increase", results: ["2x team productivity increase", "60% faster deployment cycles", "99.9% system uptime achieved", "40% reduction in tech debt"], before: caseTechvaultBefore, after: caseTechvault },
  { title: "NovaBridge Market Expansion", slug: "novabridge-expansion", category: "Growth", client: "NovaBridge", industry: "Financial Services", duration: "20 weeks", description: "Entered three new international markets within 12 months with a tailored expansion strategy.", longDescription: "NovaBridge, a growing fintech company, wanted to expand beyond their domestic market. We conducted deep market research across 8 potential regions, developed entry strategies for the top 3, and guided their leadership through regulatory compliance, localization, and partnership development. Within 12 months of engagement, NovaBridge successfully launched in three new markets — driving a 40% increase in annual revenue.", result: "40% revenue growth", results: ["40% year-over-year revenue growth", "3 new international markets", "12 strategic partnerships formed", "Regulatory approval in all regions"], before: caseNovabridgeBefore, after: caseNovabridge },
];

// ── Hero badges & mission preview ───────────────────────────
export const heroBadges = [
  { icon: Lightbulb, label: "Fresh Thinking" },
  { icon: Users, label: "Dedicated Team" },
  { icon: Globe, label: "Global Mindset" },
];

export const heroMissionServices = [
  { icon: Code2, label: "Full Stack Development", desc: "End-to-end web apps" },
  { icon: Cloud, label: "Cloud Solutions", desc: "Scalable infrastructure" },
  { icon: Brain, label: "AI & Machine Learning", desc: "Intelligent automation" },
];

// ── About Preview highlights ────────────────────────────────
export const aboutHighlights = [
  { icon: Target, label: "Purpose-Driven" },
  { icon: Users, label: "Dedicated Team" },
  { icon: Globe, label: "Global Impact" },
];

// ── Contact info ────────────────────────────────────────────
export const contactInfo = [
  { icon: "Mail" as const, label: "Email", value: "hello@t-solutions.com" },
  { icon: "Phone" as const, label: "Phone", value: "+1 (555) 123-4567" },
];
