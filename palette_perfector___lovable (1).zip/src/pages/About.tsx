import { motion } from "framer-motion";
import AnimatedSection from "@/components/AnimatedSection";
import SectionHeader from "@/components/SectionHeader";
import PageHero from "@/components/PageHero";
import { StaggerChildren, itemVariants } from "@/components/StaggerChildren";
import PageTransition from "@/components/PageTransition";
import { values, team } from "@/constants";

const About = () => {
    return (
      <PageTransition>
      <PageHero
        eyebrow="About Us"
        title={<>About <span className="text-accent italic">T-Solutions</span></>}
        description="Founded with a vision to redefine corporate consulting, T-Solutions combines strategic expertise with a deep commitment to sustainability."
      />

      {/* Mission */}
      <section className="section-padding bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <AnimatedSection direction="left">
              <p className="text-xs font-medium text-accent uppercase tracking-[0.3em] mb-4">Our Mission</p>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 leading-tight">
                Empowering sustainable growth
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6 font-light">
                To empower businesses to achieve sustainable growth by providing innovative strategies, actionable insights, and dedicated partnerships that create value for all stakeholders.
              </p>
              <p className="text-muted-foreground leading-relaxed font-light text-sm">
                Since our founding in 2015, we've helped over 200 companies across 30 industries transform their operations, reduce their environmental footprint, and increase profitability.
              </p>
            </AnimatedSection>
            <AnimatedSection direction="right" delay={0.2}>
              <div className="grid grid-cols-2 gap-6">
                {[
                  { val: "200+", label: "Clients Served" },
                  { val: "30+", label: "Industries" },
                  { val: "95%", label: "Client Retention" },
                  { val: "10+", label: "Years Experience" },
                ].map((stat, i) => (
                  <motion.div
                    key={stat.label}
                    className="glass-card rounded-2xl p-6 text-center"
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.3 + i * 0.1, duration: 0.5 }}
                  >
                    <p className="text-3xl font-bold text-foreground">{stat.val}</p>
                    <p className="text-xs text-muted-foreground mt-2 uppercase tracking-wider">{stat.label}</p>
                  </motion.div>
                ))}
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section-padding border-y border-border/50">
        <div className="container mx-auto px-4 lg:px-8">
          <SectionHeader eyebrow="Our Values" title="What drives us forward" />
          <StaggerChildren className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v) => (
              <motion.div key={v.title} variants={itemVariants}>
                <div className="glass-card rounded-2xl p-8 text-center h-full">
                  <div className="w-14 h-14 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-5">
                    <v.icon className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="text-base font-semibold text-foreground mb-3" style={{ fontFamily: "'Inter', sans-serif" }}>
                    {v.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{v.description}</p>
                </div>
              </motion.div>
            ))}
          </StaggerChildren>
        </div>
      </section>

      {/* Team */}
      <section className="section-padding bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <SectionHeader
            eyebrow="Our Team"
            title="Our Leadership"
            description="A team of experienced professionals passionate about driving meaningful change."
            centered
          />
          <StaggerChildren className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8" staggerDelay={0.1}>
            {team.map((member) => (
              <motion.div key={member.name} variants={itemVariants} className="text-center">
                <motion.div
                  className="w-24 h-24 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <span className="text-lg font-bold text-accent">{member.initials}</span>
                </motion.div>
                <h3 className="font-semibold text-foreground text-sm">{member.name}</h3>
                <p className="text-xs text-muted-foreground mt-1">{member.role}</p>
              </motion.div>
            ))}
          </StaggerChildren>
        </div>
      </section>
    </PageTransition>
  );
};

export default About;
