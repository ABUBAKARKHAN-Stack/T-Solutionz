import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { motion } from "framer-motion";
import { StaggerChildren, itemVariants } from "@/components/StaggerChildren";
import PageTransition from "@/components/PageTransition";
import PageHero from "@/components/PageHero";
import CTASection from "@/components/CTASection";
import BeforeAfterSlider from "@/components/BeforeAfterSlider";
import { caseStudies } from "@/constants";

const Portfolio = () => {
  return (
    <PageTransition>
      <PageHero
        eyebrow="Our Work"
        title={<>Case <span className="text-accent italic">Studies</span></>}
        description="Real-world projects where we turned challenges into measurable outcomes. Explore the transformations."
      />

      {/* Case Studies */}
      <section className="section-padding bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <StaggerChildren className="space-y-16" staggerDelay={0.15}>
            {caseStudies.map((study, i) => (
              <motion.div key={study.slug} variants={itemVariants}>
                <div className={`grid grid-cols-1 lg:grid-cols-2 gap-8 items-center ${i % 2 === 1 ? "lg:grid-flow-dense" : ""}`}>
                  <div className={i % 2 === 1 ? "lg:col-start-2" : ""}>
                    <div className="rounded-2xl overflow-hidden border border-border/40 shadow-sm">
                      <BeforeAfterSlider
                        beforeImage={study.before}
                        afterImage={study.after}
                        className="h-72 md:h-80"
                      />
                    </div>
                  </div>
                  <div className={`${i % 2 === 1 ? "lg:col-start-1 lg:row-start-1" : ""}`}>
                    <span className="text-[10px] font-medium uppercase tracking-wider text-accent bg-accent/10 px-2.5 py-1 rounded-full">
                      {study.category}
                    </span>
                    <h2 className="text-2xl md:text-3xl font-bold text-foreground mt-4 mb-3 leading-snug">{study.title}</h2>
                    <p className="text-sm text-muted-foreground leading-relaxed font-light mb-6">{study.description}</p>
                    <div className="flex items-center gap-6 mb-6">
                      <div>
                        <p className="text-[10px] text-muted-foreground/60 uppercase tracking-wider mb-0.5">Key Result</p>
                        <p className="text-lg font-bold text-accent">{study.result}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground/60 uppercase tracking-wider mb-0.5">Industry</p>
                        <p className="text-sm font-medium text-foreground">{study.industry}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground/60 uppercase tracking-wider mb-0.5">Duration</p>
                        <p className="text-sm font-medium text-foreground">{study.duration}</p>
                      </div>
                    </div>
                    <Link
                      to={`/portfolio/${study.slug}`}
                      className="inline-flex items-center gap-2 text-sm font-medium text-foreground hover:text-accent transition-colors group"
                    >
                      View Full Case Study
                      <ArrowUpRight className="h-4 w-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </StaggerChildren>
        </div>
      </section>

      <CTASection
        title={<>Want results <br /><span className="text-accent italic">like these?</span></>}
        description="Let's discuss how we can create a similar success story for your business."
        buttonText="Start Your Project"
      />
    </PageTransition>
  );
};

export default Portfolio;
