import { useParams, Link } from "react-router-dom";
import { ArrowLeft, ArrowUpRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import AnimatedSection from "@/components/AnimatedSection";
import PageTransition from "@/components/PageTransition";
import PageHero from "@/components/PageHero";
import SectionHeader from "@/components/SectionHeader";
import CTASection from "@/components/CTASection";
import ContactDrawer from "@/components/ContactDrawer";
import { services } from "@/constants";

const ServiceDetail = () => {
  const { slug } = useParams();
  const service = services.find((s) => s.slug === slug);

  if (!service) {
    return (
      <PageTransition>
        <section className="pt-32 pb-20 section-padding">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <h1 className="text-4xl font-bold text-foreground mb-4">Service Not Found</h1>
            <p className="text-muted-foreground mb-8">The service you're looking for doesn't exist.</p>
            <Button asChild variant="outline" className="rounded-full">
              <Link to="/services">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Services
              </Link>
            </Button>
          </div>
        </section>
      </PageTransition>
    );
  }

  const Icon = service.icon;
  const otherServices = services.filter((s) => s.slug !== slug).slice(0, 3);

  return (
    <PageTransition>
      <PageHero
        eyebrow={`Service ${service.num}`}
        title={service.title}
        description={service.description}
        backgroundImage={service.image}
      >
        <Link
          to="/services"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" /> Back to Services
        </Link>
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center">
            <Icon className="h-5 w-5 text-accent" />
          </div>
        </div>
      </PageHero>

      {/* Content */}
      <section className="section-padding bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
            <AnimatedSection className="lg:col-span-3">
              <h2 className="text-2xl font-bold text-foreground mb-6">Overview</h2>
              <p className="text-muted-foreground leading-relaxed font-light text-base">{service.longDescription}</p>

              {service.tags && (
                <div className="flex flex-wrap gap-2 mt-8">
                  {service.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-xs font-medium text-accent bg-accent/10 border border-accent/20 px-4 py-2 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </AnimatedSection>

            <AnimatedSection delay={0.2} className="lg:col-span-2">
              <div className="glass-card rounded-2xl p-8 border border-border/40">
                <h3 className="text-lg font-semibold text-foreground mb-6">Key Deliverables</h3>
                <ul className="space-y-4">
                  {service.deliverables?.map((d, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckCircle2 className="h-5 w-5 text-accent shrink-0 mt-0.5" />
                      <span className="text-sm text-muted-foreground leading-relaxed">{d}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-8 pt-6 border-t border-border/30">
                  <ContactDrawer>
                    <Button className="w-full rounded-full bg-foreground text-background hover:bg-foreground/90 font-medium">
                      Discuss This Service <ArrowUpRight className="ml-2 h-4 w-4" />
                    </Button>
                  </ContactDrawer>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Other Services */}
      <section className="section-padding bg-card/30">
        <div className="container mx-auto px-4 lg:px-8">
          <SectionHeader eyebrow="Explore More" title="Other Services" className="mb-12" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {otherServices.map((s) => {
              const SIcon = s.icon;
              return (
                <AnimatedSection key={s.slug} delay={0.1}>
                  <Link to={`/services/${s.slug}`} className="group block">
                    <div className="rounded-2xl overflow-hidden bg-card border border-border/40 hover:border-accent/40 transition-all duration-500 shadow-sm">
                      <div className="relative h-36 overflow-hidden">
                        <img src={s.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" loading="lazy" />
                        <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
                      </div>
                      <div className="p-6">
                        <div className="flex items-center gap-3 mb-2">
                          <SIcon className="h-4 w-4 text-accent" />
                          <h3 className="text-sm font-semibold text-foreground">{s.title}</h3>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{s.description}</p>
                      </div>
                    </div>
                  </Link>
                </AnimatedSection>
              );
            })}
          </div>
        </div>
      </section>

      <CTASection
        title={<>Ready to <span className="text-accent italic">get started?</span></>}
        description={`Let's discuss how ${service.title.toLowerCase()} can transform your business.`}
      />
    </PageTransition>
  );
};

export default ServiceDetail;
