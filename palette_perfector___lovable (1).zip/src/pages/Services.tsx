import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import MagneticButton from "@/components/MagneticButton";
import { StaggerChildren, itemVariants } from "@/components/StaggerChildren";
import PageTransition from "@/components/PageTransition";
import PageHero from "@/components/PageHero";
import CTASection from "@/components/CTASection";
import ServiceCard from "@/components/ServiceCard";
import { services } from "@/constants";

const Services = () => {
  return (
    <PageTransition>
      <PageHero
        eyebrow="Our Services"
        title={<>What we <span className="text-accent italic">do best</span></>}
        description="End-to-end development services designed to help your business build, ship, and scale with confidence."
      />

      {/* Services Grid */}
      <section className="section-padding bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <StaggerChildren className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s, i) => (
              <motion.div
                key={s.title}
                variants={itemVariants}
                className={
                  i === 0 || i === 3
                    ? "md:col-span-2 lg:col-span-2"
                    : ""
                }
              >
                <ServiceCard {...s} wide={i === 0 || i === 3} />
              </motion.div>
            ))}
          </StaggerChildren>
        </div>
      </section>

      <CTASection
        title={<>Need a custom<br /><span className="text-accent italic">solution?</span></>}
        description="Every business is unique. Let's talk about how we can tailor our services to your needs."
        buttonText="Get in Touch"
      />
    </PageTransition>
  );
};

export default Services;
