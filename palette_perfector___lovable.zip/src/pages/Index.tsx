import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, ArrowUpRight, Rocket, Zap } from "lucide-react";
import ContactDrawer from "@/components/ContactDrawer";
import ApproachSection from "@/components/sections/ApproachSection";
import WhyChooseUsSection from "@/components/sections/WhyChooseUsSection";
import FAQSection from "@/components/sections/FAQSection";
import PortfolioSection from "@/components/sections/PortfolioSection";
import TestimonialsSection from "@/components/sections/TestimonialsSection";
import AboutPreviewSection from "@/components/sections/AboutPreviewSection";
import ServiceCard from "@/components/ServiceCard";
import SectionHeader from "@/components/SectionHeader";
import CTASection from "@/components/CTASection";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import AnimatedSection from "@/components/AnimatedSection";
import MagneticButton from "@/components/MagneticButton";
import { StaggerChildren, itemVariants } from "@/components/StaggerChildren";
import ParallaxSection from "@/components/ParallaxSection";
import PageTransition from "@/components/PageTransition";
import { features, homeServices, partners, heroBadges, heroMissionServices } from "@/constants";

const Index = () => {
  const heroRef = useRef(null);
  const { scrollYProgress: heroScroll } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });
  const heroY = useTransform(heroScroll, [0, 1], [0, 150]);
  const heroOpacity = useTransform(heroScroll, [0, 0.8], [1, 0]);

  return (
    <PageTransition>
      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center overflow-hidden">
        {/* Film grain noise overlay */}
        <div
          className="absolute inset-0 opacity-[0.02] dark:opacity-[0.03] pointer-events-none z-[2]"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
            backgroundRepeat: 'repeat',
            backgroundSize: '128px 128px',
          }}
        />

        {/* Animated gradient mesh */}
        <motion.div className="absolute inset-0 z-[1]" style={{ y: heroY }}>
          <motion.div
            className="absolute -top-[20%] -left-[10%] w-[60%] h-[60%] rounded-full bg-accent/20 dark:bg-accent/10 blur-[120px]"
            animate={{ x: [0, 80, -40, 0], y: [0, -60, 40, 0], scale: [1, 1.2, 0.9, 1] }}
            transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            className="absolute top-[30%] -right-[10%] w-[50%] h-[50%] rounded-full bg-accent/15 dark:bg-accent/8 blur-[140px]"
            animate={{ x: [0, -60, 30, 0], y: [0, 50, -30, 0], scale: [1, 0.85, 1.15, 1] }}
            transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            className="absolute -bottom-[10%] left-[20%] w-[45%] h-[45%] rounded-full bg-accent/12 dark:bg-accent/6 blur-[160px]"
            animate={{ x: [0, 40, -60, 0], y: [0, -40, 20, 0], scale: [1, 1.1, 0.95, 1] }}
            transition={{ duration: 22, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            className="absolute top-[10%] left-[40%] w-[35%] h-[35%] rounded-full bg-accent/10 dark:bg-accent/5 blur-[130px]"
            animate={{ x: [0, -30, 50, 0], y: [0, 60, -20, 0], scale: [1, 1.15, 0.9, 1] }}
            transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
          />
        </motion.div>

        {/* Decorative vertical line */}
        <motion.div
          className="absolute left-[10%] top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-border/40 to-transparent hidden lg:block"
          initial={{ scaleY: 0 }}
          animate={{ scaleY: 1 }}
          transition={{ duration: 1.2, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
        />

        <motion.div className="container mx-auto px-6 lg:px-12 relative z-10" style={{ opacity: heroOpacity }}>
          {/* Top bar */}
          <motion.div
            className="flex items-center gap-8 pt-28 lg:pt-32 mb-16 lg:mb-20"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
              <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-[0.3em]">Now accepting new clients</span>
            </div>
            <div className="hidden md:block w-px h-4 bg-border/50" />
            <span className="hidden md:block text-[10px] font-medium text-muted-foreground uppercase tracking-[0.3em]">Fresh perspectives, proven methods</span>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-16 items-start pb-16 lg:pb-24">
            {/* Left column — main content */}
            <div className="lg:col-span-7">
              {/* Eyebrow */}
              <motion.div
                className="flex items-center gap-3 mb-8"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <div className="w-12 h-px bg-accent" />
                <span className="text-[10px] font-semibold text-accent uppercase tracking-[0.4em]">
                  Strategy · Innovation · Growth
                </span>
              </motion.div>

              {/* Headline */}
              <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] font-bold text-foreground leading-[0.92] tracking-[-0.03em] mb-8">
                {["Empowering", "Sustainable", "Growth"].map((word, i) => (
                  <span key={word} className="block overflow-hidden">
                    <motion.span
                      className="block"
                      initial={{ y: "110%" }}
                      animate={{ y: 0 }}
                      transition={{
                        duration: 0.8,
                        ease: [0.22, 1, 0.36, 1],
                        delay: 0.15 + i * 0.1,
                      }}
                    >
                      {word === "Growth" ? (
                        <motion.span
                          className="text-accent italic"
                          initial={{ opacity: 0, filter: "blur(8px)" }}
                          animate={{ opacity: 1, filter: "blur(0px)" }}
                          transition={{ duration: 0.8, delay: 0.55 }}
                        >
                          {word}
                        </motion.span>
                      ) : (
                        word
                      )}
                    </motion.span>
                  </span>
                ))}
              </h1>

              {/* Subtext */}
              <motion.p
                className="text-base md:text-lg text-muted-foreground max-w-lg leading-[1.8] font-light mb-10"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                We partner with forward-thinking companies to build strategies
                that drive growth, foster innovation, and create lasting impact.
              </motion.p>

              {/* CTAs */}
              <motion.div
                className="flex flex-wrap items-center gap-4"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
              >
                <MagneticButton>
                  <Button asChild size="lg" className="rounded-full bg-foreground text-background hover:bg-foreground/90 text-sm px-8 h-12 font-medium tracking-wide">
                    <Link to="/services">
                      Our Services <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </MagneticButton>
                <MagneticButton>
                  <ContactDrawer>
                    <Button variant="ghost" size="lg" className="rounded-full text-foreground hover:bg-accent/10 text-sm px-6 h-12 font-medium">
                      Get in Touch →
                    </Button>
                  </ContactDrawer>
                </MagneticButton>
              </motion.div>

              {/* Trust badges */}
              <motion.div
                className="flex items-center gap-6 mt-14 pt-8 border-t border-border/30"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.8 }}
              >
                {heroBadges.map((badge) => (
                  <div key={badge.label} className="flex items-center gap-2">
                    <badge.icon className="h-3.5 w-3.5 text-accent" />
                    <span className="text-[11px] font-medium text-muted-foreground">{badge.label}</span>
                  </div>
                ))}
              </motion.div>
            </div>

            {/* Right column — services preview + mission */}
            <motion.div
              className="lg:col-span-5"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.7 }}
            >
              <div className="space-y-5">
                {/* Mission card */}
                <div className="glass-card rounded-3xl p-8 md:p-10 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-[60px]" />
                  
                  <div className="flex items-center gap-3 mb-6 relative z-10">
                    <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                    <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-[0.3em]">Our Mission</span>
                  </div>

                  <p className="text-lg md:text-xl font-semibold text-foreground leading-relaxed mb-6 relative z-10" style={{ fontFamily: "'Playfair Display', serif" }}>
                    "We believe every business deserves a strategy that's as ambitious as its vision."
                  </p>

                  <div className="space-y-4 relative z-10">
                    {heroMissionServices.map((service, i) => (
                      <motion.div
                        key={service.label}
                        className="flex items-center gap-4 p-3 rounded-xl hover:bg-accent/5 transition-colors duration-300 cursor-default"
                        initial={{ opacity: 0, x: -15 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: 0.9 + i * 0.1 }}
                      >
                        <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
                          <service.icon className="h-4 w-4 text-accent" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{service.label}</p>
                          <p className="text-xs text-muted-foreground">{service.desc}</p>
                        </div>
                        <ArrowUpRight className="h-3.5 w-3.5 text-muted-foreground/40 ml-auto" />
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Small accent cards row */}
                <div className="grid grid-cols-2 gap-4">
                  <motion.div
                    className="glass-card rounded-2xl p-5 text-center"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 1.2 }}
                  >
                    <Rocket className="h-5 w-5 text-accent mx-auto mb-2" />
                    <p className="text-sm font-bold text-foreground">Launch-Ready</p>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider">From Day One</p>
                  </motion.div>
                  <motion.div
                    className="glass-card rounded-2xl p-5 text-center"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 1.3 }}
                  >
                    <Zap className="h-5 w-5 text-accent mx-auto mb-2" />
                    <p className="text-sm font-bold text-foreground">Agile-First</p>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Methodology</p>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Scroll indicator */}
          <motion.div
            className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5, duration: 0.6 }}
          >
            <span className="text-[9px] uppercase tracking-[0.3em] text-muted-foreground/60">Scroll</span>
            <motion.div
              className="w-5 h-8 rounded-full border border-border/40 flex items-start justify-center p-1"
              animate={{ y: [0, 4, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="w-1 h-2 rounded-full bg-accent/50" />
            </motion.div>
          </motion.div>
        </motion.div>
      </section>

      {/* Features Section with Parallax */}
      <ParallaxSection speed={0.15}>
        <section className="section-padding bg-background relative">
          <div className="container mx-auto px-4 lg:px-8">
            <SectionHeader
              eyebrow="What We Offer"
              title="Solutions built for the future"
              className="mb-20"
            />

            <StaggerChildren className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature) => (
                <motion.div key={feature.title} variants={itemVariants}>
                  <div className="group glass-card rounded-2xl p-8 h-full cursor-default">
                    <div className="flex items-start justify-between mb-6">
                      <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors duration-500">
                        <feature.icon className="h-5 w-5 text-accent" />
                      </div>
                      <span className="text-xs font-mono text-muted-foreground/40">{feature.num}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-3" style={{ fontFamily: "'Inter', sans-serif" }}>
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </StaggerChildren>
          </div>
        </section>
      </ParallaxSection>

      {/* Services Section */}
      <section className="section-padding bg-card/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-accent/5 rounded-full blur-[150px]" />
        <div className="container mx-auto px-4 lg:px-8 relative z-10">
          <SectionHeader
            eyebrow="Our Services"
            title={<>What we <span className="text-accent italic">do best</span></>}
            action={
              <MagneticButton>
                <Button asChild variant="outline" className="rounded-full border-border text-foreground hover:bg-accent/10 text-sm px-6 h-10 font-medium">
                  <Link to="/services">
                    View All Services <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </MagneticButton>
            }
          />

          <StaggerChildren className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" staggerDelay={0.08}>
            {homeServices.map((s, i) => (
              <motion.div
                key={s.title}
                variants={itemVariants}
                className={
                  i === 0 || i === 3
                    ? "md:col-span-2 lg:col-span-2"
                    : ""
                }
              >
                <ServiceCard {...s} wide={i === 0 || i === 3} />
              </motion.div>
            ))}
          </StaggerChildren>
        </div>
      </section>

      {/* Partners Section with Parallax */}
      <ParallaxSection speed={0.1}>
        <section className="py-20 border-y border-border/50">
          <div className="container mx-auto px-4 lg:px-8">
            <SectionHeader
              eyebrow="Trusted Partners"
              title="Collaborating with ambitious brands"
              centered
            />
            <StaggerChildren className="flex flex-wrap justify-center items-center gap-12 md:gap-20" staggerDelay={0.06}>
              {partners.map((partner) => (
                <motion.span
                  key={partner}
                  variants={itemVariants}
                  className="text-xl md:text-2xl font-semibold text-muted-foreground/20 hover:text-accent/60 transition-colors duration-500 cursor-default"
                  style={{ fontFamily: "'Inter', sans-serif" }}
                >
                  {partner}
                </motion.span>
              ))}
            </StaggerChildren>
          </div>
        </section>
      </ParallaxSection>

      {/* About Preview */}
      <AboutPreviewSection />

      {/* Testimonials Section */}
      <TestimonialsSection />

      {/* Portfolio / Case Studies */}
      <PortfolioSection />

      {/* Our Approach */}
      <ApproachSection />

      {/* Why Choose Us */}
      <WhyChooseUsSection />

      {/* FAQ */}
      <FAQSection />

      <CTASection
        title={<>Let's build something<br /><span className="text-accent italic">extraordinary</span></>}
        description="Ready to transform your business? Schedule a free consultation and discover what's possible."
        extraActions={
          <MagneticButton>
            <Button asChild variant="outline" size="lg" className="rounded-full border-border text-foreground hover:bg-accent/10 text-sm px-8 h-12 font-medium">
              <Link to="/about">
                Learn About Us <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </MagneticButton>
        }
      />
    </PageTransition>
  );
};

export default Index;
