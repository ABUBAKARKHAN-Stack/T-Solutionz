import { useParams, Link } from "react-router-dom";
import { ArrowLeft, ArrowUpRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import AnimatedSection from "@/components/AnimatedSection";
import PageTransition from "@/components/PageTransition";
import PageHero from "@/components/PageHero";
import SectionHeader from "@/components/SectionHeader";
import CTASection from "@/components/CTASection";
import ContactDrawer from "@/components/ContactDrawer";
import BeforeAfterSlider from "@/components/BeforeAfterSlider";
import { caseStudies } from "@/constants";

const PortfolioDetail = () => {
  const { slug } = useParams();
  const study = caseStudies.find((s) => s.slug === slug);

  if (!study) {
    return (
      <PageTransition>
        <section className="pt-32 pb-20 section-padding">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <h1 className="text-4xl font-bold text-foreground mb-4">Case Study Not Found</h1>
            <p className="text-muted-foreground mb-8">The case study you're looking for doesn't exist.</p>
            <Button asChild variant="outline" className="rounded-full">
              <Link to="/portfolio">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Portfolio
              </Link>
            </Button>
          </div>
        </section>
      </PageTransition>
    );
  }

  const otherStudies = caseStudies.filter((s) => s.slug !== slug);

  return (
    <PageTransition>
      <PageHero
        eyebrow={study.category}
        title={study.title}
        description={study.description}
        backgroundImage={study.after}
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Portfolio", href: "/portfolio" },
          { label: study.title },
        ]}
      >
        <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground mb-6">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground/60">Client</span>
            <p className="font-medium text-foreground">{study.client}</p>
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground/60">Industry</span>
            <p className="font-medium text-foreground">{study.industry}</p>
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground/60">Duration</span>
            <p className="font-medium text-foreground">{study.duration}</p>
          </div>
        </div>
      </PageHero>

      {/* Before/After */}
      <section className="section-padding bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
            <AnimatedSection className="lg:col-span-3">
              <h2 className="text-2xl font-bold text-foreground mb-6">The Challenge & Solution</h2>
              <p className="text-muted-foreground leading-relaxed font-light text-base">{study.longDescription}</p>

              <div className="mt-10 rounded-2xl overflow-hidden border border-border/40 shadow-sm">
                <BeforeAfterSlider
                  beforeImage={study.before}
                  afterImage={study.after}
                  className="h-64 md:h-80"
                />
              </div>
            </AnimatedSection>

            <AnimatedSection delay={0.2} className="lg:col-span-2">
              <div className="glass-card rounded-2xl p-8 border border-border/40">
                <h3 className="text-lg font-semibold text-foreground mb-6">Key Results</h3>
                <ul className="space-y-4">
                  {study.results?.map((r, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckCircle2 className="h-5 w-5 text-accent shrink-0 mt-0.5" />
                      <span className="text-sm text-muted-foreground leading-relaxed">{r}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-8 pt-6 border-t border-border/30">
                  <ContactDrawer>
                    <Button className="w-full rounded-full bg-foreground text-background hover:bg-foreground/90 font-medium">
                      Start a Similar Project <ArrowUpRight className="ml-2 h-4 w-4" />
                    </Button>
                  </ContactDrawer>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Other Case Studies */}
      {otherStudies.length > 0 && (
        <section className="section-padding bg-card/30">
          <div className="container mx-auto px-4 lg:px-8">
            <SectionHeader eyebrow="More Work" title="Other Case Studies" className="mb-12" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {otherStudies.map((s) => (
                <AnimatedSection key={s.slug} delay={0.1}>
                  <Link to={`/portfolio/${s.slug}`} className="group block">
                    <div className="rounded-2xl overflow-hidden bg-card border border-border/40 hover:border-accent/40 transition-all duration-500 shadow-sm">
                      <div className="relative h-48 overflow-hidden">
                        <img src={s.after} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" loading="lazy" />
                        <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
                      </div>
                      <div className="p-6">
                        <span className="text-[10px] font-medium uppercase tracking-wider text-accent bg-accent/10 px-2 py-0.5 rounded-full">
                          {s.category}
                        </span>
                        <h3 className="text-lg font-semibold text-foreground mt-3 mb-2">{s.title}</h3>
                        <p className="text-xs text-muted-foreground line-clamp-2">{s.description}</p>
                        <p className="text-sm font-bold text-accent mt-3">{s.result}</p>
                      </div>
                    </div>
                  </Link>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>
      )}

      <CTASection
        title={<>Your success story <span className="text-accent italic">starts here</span></>}
        description="Let's build something remarkable together."
      />
    </PageTransition>
  );
};

export default PortfolioDetail;
